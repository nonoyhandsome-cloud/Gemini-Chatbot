import express from 'express';
import dotenv from 'dotenv';
import { GoogleGenerativeAI } from '@google/generative-ai';

// --- Basic Setup ---
dotenv.config();
const app = express();
const port = process.env.PORT || 3000;

// Check for API Key
if (!process.env.GEMINI_API_KEY) {
  console.error('🔴 FATAL ERROR: GEMINI_API_KEY is not set in the .env file.');
  process.exit(1); // Stop the server if the key is missing
}

// Initialize the Gemini AI Client
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });

// In-memory chat history (for simplicity, resets on server restart)
let chatHistory = [];

// --- Middleware ---
app.use(express.json()); // To parse JSON request bodies
app.use(express.static('public')); // To serve static files like index.html

// --- API Routes ---

// Endpoint to handle a new chat message
app.post('/api/chat', async (req, res) => {
  const { message } = req.body;
  if (!message) {
    return res.status(400).json({ error: 'Message is required' });
  }

  try {
    // Add the user's message to our history
    chatHistory.push({ role: 'user', parts: [{ text: message }] });

    // Format history for the API
    const formattedHistory = chatHistory.slice(0, -1); // Exclude the latest user message

    // Start a chat session with the full history
    const chat = model.startChat({
      history: formattedHistory,
    });

    // Send the latest message to the model
    const result = await chat.sendMessage(message);
    const response = result.response;
    const botReply = response.text();

    // Add the bot's response to our history
    chatHistory.push({ role: 'model', parts: [{ text: botReply }] });

    // Send just the bot's latest reply back to the frontend
    res.json({ reply: botReply });

  } catch (error) {
    console.error('Error with Gemini API:', error);
    res.status(500).json({ error: 'Failed to get a response from the AI.' });
  }
});

// --- Start Server ---
app.listen(port, () => {
  console.log(`🚀 Server is running at http://localhost:${port}`);
  console.log('Press Ctrl+C to stop the server.');
});